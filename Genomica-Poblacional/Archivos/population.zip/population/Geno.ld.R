---
title: "Geno.ld.summ"
output: html_document
---

```{r}

library(ggplot2)
library(readr)
library(dplyr)
library(tidyverse)
install.packages(cowplot)
library(cowplot)

EU <- read_delim("EU.geno.ld", delim = "\t")
OC <- read_delim("OC.geno.ld", delim = "\t")
US <- read_delim("US.geno.ld", delim = "\t")

EU$dist <- ceiling((EU$POS2 - EU$POS1)/1000)*1000
OC$dist <- ceiling((OC$POS2 - OC$POS1)/1000)*1000
US$dist <- ceiling((US$POS2 - US$POS1)/1000)*1000

EU2 <- group_by(EU,dist) %>% summarise(meanR2 = mean(`R^2`))

OC2 <- group_by(OC,dist) %>% summarise(meanR2 = mean(`R^2`))

US2 <- group_by(US,dist) %>% summarise(meanR2 = mean(`R^2`))  

dd <- bind_rows(EU2,OC2,US2)

dd$pop <- rep(c("EU","OC","US"),c(nrow(EU2),nrow(OC2),nrow(US2))) 

write_csv(dd,"EU_OC_US.windowed.ld.csv")

```

```{r}

het <- read_delim("EU_OC_US.het",delim = "\t")
het

```

```{r}

het$Heterozygosity <- 1-(het$`O(HOM)`/het$N_SITES) 
het$Population <- c(rep("EU",3),rep("OC",3),rep("US",3))
Aplot <- ggplot(het,aes(x = Population, y = Heterozygosity, col = Population)) +
  geom_point()+
  theme_bw()+
  theme(legend.position = "none")+
  xlab("")
plot(Aplot)

```
